//: [Previous](@previous)

import Foundation

//func upload(product: Product) {}

protocol Uploadable {
    func toJson() -> [String: Any]
}

struct Mobile: Uploadable {
    let name: String
    let osVersion: String
    
    func toJson() -> [String: Any] {
        var body: [String: Any] = [:]
        body["name"] = name
        body["osVersion"] = osVersion
        return body
    }
}

struct Book: Uploadable {
    let name: String
    let totalPage: Int
    
    func toJson() -> [String: Any] {
        var body: [String: Any] = [:]
        body["name"] = name
        body["totalPage"] = totalPage
        return body
    }
}

func upload(product: Uploadable)  {
    let json = product.toJson() // this enables SRP where each object is responsible for creating their own json
    // Upload json to server
}

upload(product: Book(name: "Name", totalPage: 10))
upload(product: Mobile(name: "Mobile Name", osVersion: "12.1"))

//: [Next](@next)


