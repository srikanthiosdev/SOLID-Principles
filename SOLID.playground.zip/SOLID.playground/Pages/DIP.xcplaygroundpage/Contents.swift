//: [Previous](@previous)

import Foundation

protocol Uploadable {
    func toJson() -> [String: Any]
}

protocol Downloadable {
    init(from dictionary: [String: Any]) throws
}

protocol Mappable: Downloadable, Uploadable {}

struct DownloadableError: Error {}

class Product: Mappable {
    
    var name: String = "Some product name"

    required init(from dictionary: [String : Any]) throws {
        guard let name = dictionary["name"] as? String else { throw DownloadableError()}
        self.name = name
    }
    
    func toJson() -> [String: Any] {
        var body: [String: Any] = [:]
        body["name"] = name
        return body
    }
}

class Mobile: Product {
    let osVersion: String
    
    required init(from dictionary: [String: Any]) throws {
        guard let osVersion = dictionary["osVersion"] as? String else { throw DownloadableError()}
        self.osVersion = osVersion
        try super.init(from: dictionary)
    }
    
    override func toJson() -> [String: Any] {
        var body: [String: Any] = super.toJson()
        body["osVersion"] = osVersion
        return body
    }
}



//struct ProductManager {
//    let service: FirebaseProductService
//
//    func add(product: Mobile) throws -> Mobile {
//        let requestBody = product.toJson()
//        let responseBody = service.add(body: requestBody)
//        return try Mobile(from: responseBody)
//    }
//}



protocol ProductService {
    func add(body: [String: Any]) -> [String: Any]
}

class FirebaseProductService: ProductService {
    func add(body: [String: Any]) -> [String: Any] {
        // Connects Firebase server and returns book
        // https://firebase.zopsmart.com/add
        return body
    }
}

class AWSProductService: ProductService {
    func add(body: [String: Any]) -> [String: Any] {
        // Connects AWS server and returns book
        // https://aws.zopsmart.com/add
        return body
    }
}

class MockService: ProductService {
    func add(body: [String: Any]) -> [String: Any] {
        // Connects AWS server and returns book
        // https://aws.zopsmart.com/add
        return body
    }
}

struct ProductManager {
    let service: ProductService // DIP

    func add<T: Mappable>(product: T) throws -> T {
        let requestBody = product.toJson()// SIP && OCP && LSP, ISP
        let responseBody = service.add(body: requestBody)
        return try T(from: responseBody)
    }
}

let manager = ProductManager(service: FirebaseProductService())
let manager2 = ProductManager(service: MockService())
let result = try manager.add(product: Product(from: ["name": "Product Name"]))
let result2 = try manager2.add(product: Product(from: ["name": "Product Name"]))

//: [Next](@next)
