//: [Previous](@previous)

import Foundation

struct Product {
    let name: String
    let totalPage: Int
    let osVersion: String
    let productType: String

    func takePicture() {}
    func goNextPage() {}
}

func upload(product: Product) {
    var json: [String: Any] = [:]
    json["name"] = product.name
    if product.productType == "book" {
        json["totalPage"] = product.totalPage
    } else if product.productType == "mobile" {
        json["osVersion"] = product.osVersion
    }
    // upload json to server
}


struct Mobile {
    let name: String
    let osVersion: String

    func takePicture() {}
}

struct Book {
    let name: String
    let totalPage: Int

    func goNextPage() {}
}
