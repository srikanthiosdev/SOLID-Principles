//: [Previous](@previous)

import Foundation

protocol Uploadable {
    func toJson() -> [String: Any]
}

protocol Downloadable {
    init(from dictionary: [String: Any]) throws
}

protocol Mappable {
    init(from dictionary: [String: Any]) throws
    func toJson() -> [String: Any]
} // Use Codable, using this to understand easier

struct DownloadableError: Error {}

struct PersonInformation: Mappable {
    let firstName: String
    let lastName: String
    
    init(from dictionary: [String : Any]) throws {
        guard let firstName = dictionary["firstName"] as? String else { throw DownloadableError()}
        guard let lastName = dictionary["lastName"] as? String else { throw DownloadableError()}
        self.init(firstName: firstName, lastName: lastName)
    }
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    func toJson() -> [String : Any] {
        var body: [String: Any] = [:]
        body["firstName"] = firstName
        body["lastName"] = lastName
        return body
    }
}

//protocol Uploadable {
//    func toJson() -> [String: Any]
//}
//
//protocol Downloadable {
//    init(from dictionary: [String: Any]) throws
//}
//
//protocol Mappable: Uploadable, Downloadable {
//}

struct User: Downloadable {
    let firstName: String
    let lastName: String
    let email: String
    let phone: String
    
    init(from dictionary: [String : Any]) throws {
        guard let firstName = dictionary["firstName"] as? String else { throw DownloadableError()}
        guard let lastName = dictionary["lastName"] as? String else { throw DownloadableError()}
        guard let email = dictionary["email"] as? String else { throw DownloadableError()}
        guard let phone = dictionary["phone"] as? String else { throw DownloadableError()}
        self.init(firstName: firstName, lastName: lastName, email: email, phone: phone)
    }
    
    init(firstName: String, lastName: String, email: String, phone: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.phone = phone
    }
}


//: [Next](@next)
