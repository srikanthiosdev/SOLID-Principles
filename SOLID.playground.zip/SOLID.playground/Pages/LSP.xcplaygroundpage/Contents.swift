////: [Previous](@previous)
//
//import Foundation
//
///*
// 1. Calling the wrong extension, to call right one we need to type cast
// 2.
// */
//


//struct Product {
//    let isPremium: Bool
//    func show() {}
//}
//
//class User {
//    func show(product: Product) {
//        product.show()
//    }
//}
//
//
//class AnonymousUser: User {
//    override func show(product: Product) {
//        if !product.isPremium {
//            super.show(product: product)
//        }
//    }
//}
//
//
//func showProduct(to user: User) {
//    let product = Product(isPremium: false)
//    user.show(product: product)
//}
//
//showProduct(to: User())
//showProduct(to: AnonymousUser())
//showProduct(to: PremiumUser())


// -------------

//struct Product {
//    let isPremium: Bool
//    func show() {}
//}
//
//class User {
//    var canWatchPremium: Bool {
//        false
//    }
//
//    func show(product: Product) {
//        if product.isPremium == canWatchPremium {
//            product.show()
//        } else {
//            product.show()
//        }
//    }
//}
//
//
//class AnonymousUser: User {
//    override var canWatchPremium: Bool {
//        false
//    }
//    override func show(product: Product) {
//        super.show(product: product)
//    }
//}
//
//class PremiumUser: User {
//    override var canWatchPremium: Bool { true}
//
//    override func show(product: Product) {
//        super.show(product: product)
//    }
//}
//
//func showProduct(to user: User) {
//    let product = Product(isPremium: false)
//    user.show(product: product)
//}
//
//showProduct(to: User())
//showProduct(to: AnonymousUser())
//showProduct(to: PremiumUser())




protocol Uploadable {
    func toJson() -> [String: Any]
}

class Product: Uploadable {
    let name: String = "Some product name"

    func toJson() -> [String: Any] {
        var body: [String: Any] = [:]
        body["name"] = name
        return body
    }
}

class Book: Product {
    let totalPage: Int = 100

    override func toJson() -> [String: Any] {
        var body: [String: Any] = super.toJson()
        body["totalPage"] = totalPage
        return body
    }
}

func upload(product: Uploadable)  {
    let json = product.toJson() // this enables SRP where each object is responsible for creating their own json
    // Upload json to server
}

upload(product: Book())
//upload(product: Mobile()
